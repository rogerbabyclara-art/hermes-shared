# Hermes changelog: v0.12.0 (2026-04-30) → HEAD (surveyed 2026-05-09)

871 commits behind at survey time. Notable `feat` commits extracted from local git log.

## New capabilities

| Area | Commit | Summary |
|------|--------|---------|
| Video | `c9a3f36` | `video_analyze` tool — native video understanding |
| Goals | `265bd59` | `/goal` command — persistent cross-turn Ralph-loop goals |
| ACP | `e27b0b7` | `/steer` and `/queue` slash commands in ACP mode |
| OpenRouter | `457c7b7` | Response caching support |
| Kanban | `c86842` | Durable multi-profile collaboration board |
| Skills | `7cbe9a` | `here.now` built-in skill (current time/location context) |
| Skills | `180a7` | Shopify optional skill (Admin + Storefront GraphQL) |
| TUI model picker | `77fe7a` | Shows all providers; inline API key setup |
| TUI model picker | `f4c761` | `d` keybind to disconnect a provider inline |
| TUI | `bbbce0` | Self-improvement review summaries in transcript |
| Gateway | `0ab2d7` | Private notice delivery |
| Gateway | `f99676` | Auto-restart when source files change |
| Gateway | `4caad2` | Auto-delete slash-command system notices after TTL |
| Gateway | `77cbe9` | Restart manual profile gateways after `hermes update` |
| Dashboard | `e2a495` | Plugins page with enable/disable, auth status, install/remove |
| Dashboard | `226fd7` | Interactive column sorting in analytics tables |
| Dashboard | `f4c76` | hide/show toggle for dashboard plugins in sidebar |
| Feishu | `b94cb8` | Operator-configurable bot admission and mention policy |
| Update | `50c046` | `hermes update --yes` / `-y` flag — skip interactive prompt |
| Teams | `624057` | Set User-Agent header for Microsoft Teams |
| QQBot | `3792b7` | C2C and group chat support in `send_message` |

## Important fixes for this setup

| Fix | Commit | Why it matters |
|-----|--------|----------------|
| Gateway crash recovery | `f1e029` | Resume sessions after crash/restart instead of blanket suspend |
| Gateway update restart | `77cbe9` | Restart manual profile gateways after update |
| Gateway systemd retry | `f98b5d` | Retries indefinitely with backoff (previously could stop retrying) |
| Telegram polling liveness | `2470434` | Probe after reconnect to detect wedged Updater |
| WhatsApp security | `55647a` | Pin protobufjs ≥7.5.5 (3 critical CVEs) |
| write_file silent zero-byte | `e527020` | Now rejects missing content/path instead of writing 0 bytes |
| Credential pool seeding | `2ef1ad2` | Prefer `~/.hermes/.env` over `os.environ` |
| config.yaml wins over .env | `e444d8f` | agent/display/timezone settings: config.yaml takes precedence |
| Compressor | `408dd8a` | Skip non-string tool content in dedup pass (prevents AttributeError) |
| Discord zombie websockets | `292d2fb` | Close old client before reconnect |
| Slack user isolation | `a147164` | Preserve per-user slash-command session isolation |

## How to upgrade

```bash
hermes update --yes
```

After upgrade, restart gateway:
```bash
systemctl --user restart hermes-gateway
systemctl --user status hermes-gateway
```
