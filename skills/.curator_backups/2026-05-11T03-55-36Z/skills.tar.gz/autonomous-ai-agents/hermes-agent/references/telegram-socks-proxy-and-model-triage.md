# Telegram gateway SOCKS proxy + model-provider triage notes

Context captured from a Hermes gateway repair session where Telegram Bot API was reachable with curl but the systemd `hermes-gateway` Telegram adapter repeatedly logged `httpx.ConnectError: All connection attempts failed`.

## Symptoms

- `systemctl --user is-active hermes-gateway` returns `active`, but Telegram platform is not connected.
- Logs show repeated startup failures:
  - `[Telegram] Connect attempt N/8 failed: httpx.ConnectError: All connection attempts failed`
  - `telegram connect timed out after 30s`
  - `✗ telegram failed to connect`
- Direct curl through the configured SOCKS proxy can still succeed:
  - `curl --proxy "$TELEGRAM_PROXY" https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/getMe`
  - HTTP 200 with bot username proves token and basic proxy path are valid.
- A separate model/provider issue can be present at the same time: Hermes cron/agent calls returned HTTP 403 `Your request was blocked`, so do not conflate Telegram transport failure with model failure.

## Useful probes

Redact credentials in any user-facing output.

```bash
systemctl --user is-active hermes-gateway
systemctl --user status hermes-gateway --no-pager | sed -n '1,20p'
journalctl --user -u hermes-gateway --since '10 min ago' --no-pager \
  | grep -E 'Telegram|ConnectError|TimedOut|Connected|polling|HTTP 403|blocked|cron.scheduler' \
  | tail -80

PROXY=$(sed -n 's/^Environment=TELEGRAM_PROXY=//p' ~/.config/systemd/user/hermes-gateway.service.d/proxy.conf | awk '{print $1}')
set -a; . ~/.hermes/.env; set +a
curl -sS --proxy "$PROXY" "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" \
  -o /tmp/tggetme.json -w 'http=%{http_code} total=%{time_total}\n' --max-time 20
python3 - <<'PY'
import json
print(json.dumps(json.load(open('/tmp/tggetme.json')), ensure_ascii=False)[:300])
PY
```

Manual adapter proof, useful when systemd startup behaves differently:

```bash
systemctl --user stop hermes-gateway
sleep 3
set -a; . ~/.hermes/.env; set +a
export TELEGRAM_PROXY=$(sed -n 's/^Environment=TELEGRAM_PROXY=//p' ~/.config/systemd/user/hermes-gateway.service.d/proxy.conf | awk '{print $1}')
cd ~/.hermes/hermes-agent
timeout 60 .venv/bin/python - <<'PY'
import asyncio, os, time, logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s %(name)s: %(message)s')
from gateway.platforms.telegram import TelegramAdapter
from gateway.config import PlatformConfig
async def main():
    ad = TelegramAdapter(PlatformConfig(token=os.environ['TELEGRAM_BOT_TOKEN'], enabled=True, extra={}))
    t = time.time()
    try:
        ok = await ad.connect()
        print('CONNECT_RETURN', ok, '%.2fs' % (time.time() - t))
    finally:
        await ad.disconnect()
asyncio.run(main())
PY
systemctl --user start hermes-gateway
```

## Pitfalls / fixes

- Preserve `socks5h://` if the user configured it. Remote DNS matters for Telegram in polluted DNS environments. A normalizer that rewrites `socks5h://` to `socks5://` can make python/httpx fail even when curl with `socks5h://` works.
- `systemd` drop-ins can set multiple env vars on one `Environment=` line, e.g. `Environment=TELEGRAM_PROXY=... HERMES_GATEWAY_PLATFORM_CONNECT_TIMEOUT=90`, but when extracting just the proxy for probes use `awk '{print $1}'`.
- If `systemctl restart` hangs in `deactivating (stop-sigterm)`, wait for `TimeoutStopSec` or explicitly inspect the old process before judging the new config. Don't claim the gateway is fixed from `active` alone.
- Use a longer platform connect timeout only as a mitigation/diagnostic, not proof of success: `HERMES_GATEWAY_PLATFORM_CONNECT_TIMEOUT=90`.
- Separate provider failures from Telegram failures. A model request returning HTTP 403 `Your request was blocked` can break cron replies even when Telegram Bot API is healthy.

## Verification standard

A real fix requires all of:

1. `getMe` through the exact gateway proxy returns HTTP 200.
2. Gateway logs show `Connected to Telegram (polling mode)` after a clean systemd restart.
3. No new `ConnectError`/`TimedOut` loop appears for at least one polling cycle.
4. If the user asked to change models, `hermes chat -q '只回复 OK' --toolsets ''` succeeds with the configured model/provider; parser/config checks alone are not enough.
