# Gateway/model latency triage example — 2026-05-05

Use this as a compact reference when Hermes feels "stuck" after a model/provider/proxy change.

## Symptoms observed

- Telegram gateway was active, but replies appeared delayed/stuck.
- Gateway logs contained repeated Telegram transport errors:
  - `httpx.ConnectError`
  - `Timed out`
  - `polling reconnect failed`
  - `failed to send`
- Model provider was reachable, but simple chat completions were several seconds even without tools.

## Probe pattern that separated causes

1. Check live gateway and logs, not just config:
   ```bash
   systemctl --user is-active hermes-gateway
   grep -i "timed out\|connecterror\|failed to send\|polling reconnect failed" ~/.hermes/logs/gateway.log | tail -80
   ```

2. Test the same Telegram proxy used by gateway/scripts; redact credentials in output:
   ```bash
   python3 - <<'PY'
   import re, pathlib, subprocess, time
   proxy=re.search(r'PROXY\s*=\s*"([^"]+)"', pathlib.Path('/home/dev/.hermes/scripts/rss_check_new.py').read_text()).group(1)
   for name,url in [('telegram','https://api.telegram.org'),('google204','https://www.google.com/generate_204'),('youtube_rss','https://www.youtube.com/feeds/videos.xml?channel_id=UC_x5XG1OV2P6uZZ5FSM9Ttw')]:
       print('##', name)
       for i in range(3):
           p=subprocess.run(['curl','--proxy',proxy,'-L','-o','/dev/null','-sS','-w','http=%{http_code} total=%{time_total} connect=%{time_connect} tls=%{time_appconnect} ttfb=%{time_starttransfer} speed=%{speed_download} size=%{size_download}\n','--connect-timeout','6','--max-time','15',url],capture_output=True,text=True,timeout=20)
           print(f'run{i+1} rc={p.returncode} '+((p.stdout+p.stderr).strip().replace(proxy,'[PROXY]').splitlines()[-1] if (p.stdout+p.stderr).strip() else ''))
           time.sleep(.2)
   PY
   ```

3. Test provider API directly with `curl` from config, without printing API keys:
   ```bash
   python3 - <<'PY'
   import yaml, pathlib, subprocess, json, re, time
   cfg=yaml.safe_load((pathlib.Path.home()/'.hermes/config.yaml').read_text())
   base=cfg['model']['base_url'].rstrip('/'); model=cfg['model']['default']; key=cfg['model']['api_key']
   body=json.dumps({'model':model,'messages':[{'role':'user','content':'Reply exactly OK.'}],'max_tokens':8,'stream':False})
   for i in range(3):
       p=subprocess.run(['curl','-sS','-o','/tmp/model_probe.json','-w','http=%{http_code} total=%{time_total} connect=%{time_connect} tls=%{time_appconnect} ttfb=%{time_starttransfer} size=%{size_download}\n','--connect-timeout','10','--max-time','60','-H','Content-Type: application/json','-H',f'Authorization: Bearer {key}','-d',body,base+'/chat/completions'],capture_output=True,text=True,timeout=70)
       print(f'run{i+1} rc={p.returncode} {p.stdout.strip() or p.stderr.strip()}')
       time.sleep(.3)
   PY
   ```

4. Test Hermes CLI end-to-end with tools disabled:
   ```bash
   /usr/bin/time -f 'wall=%es exit=%x' hermes chat -q '只回复 OK' --toolsets ''
   ```

## Interpretation used

- If gateway logs show many Telegram network errors and proxy probes timeout, Telegram/proxy is the primary cause of "stuck" user-visible behavior.
- If direct provider `chat/completions` is already 4–8s for tiny prompts, the model/provider path is a secondary latency contributor.
- If `hermes chat -q ... --toolsets ''` is still 10s+, framework/session overhead exists but is not necessarily the root cause; compare against direct provider timing.
- Changing `reasoning_effort: high` to `medium`/`low` is a low-risk diagnostic for reasoning-capable models, but don't call it fixed until direct API and end-to-end probes improve.

## Session-specific result shape

In this case, the proxy path had severe Telegram/Google/YouTube failures, while direct gpt-5.5 provider calls succeeded but took several seconds. Conclusion: network/proxy was the main culprit; gpt-5.5/provider latency was the secondary culprit.
