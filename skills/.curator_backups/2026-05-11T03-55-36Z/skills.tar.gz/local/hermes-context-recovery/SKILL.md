---
name: hermes-context-recovery
description: Safely resume interrupted or context-compressed Hermes tasks by verifying actual state, reconstructing missing context, and only then continuing.
version: 0.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [context-compression, resume, recovery, task-handoff, verification]
    related_skills: [hermes-investigate, plan]
---

# Hermes Context Recovery

Use this skill when a session was interrupted, compacted, or resumed with only a preserved todo list and partial context.

## Trigger phrases
- continue
- 继续
- pick up where we left off
- resume this
- active task list was preserved
- after context compression
- task list is here, continue

## Goals
- Recover the real current state before acting
- Distinguish verified facts from stale todo text
- Avoid blind or empty tool calls caused by missing context
- Ask the user only for the smallest missing identifier if tools cannot recover it

## Primary tools
- todo to read preserved task state
- terminal for pwd, git status, and live repo checks
- search_files/read_file for locating relevant files and confirming repo contents
- session_search when the missing context may live in a prior session
- skill_view for any domain skill that becomes relevant after recovery

## Workflow
1. Treat preserved todos as hypotheses, not proof of completion or current scope.
2. Reconstruct the actual environment first:
   - check current workspace/path
   - inspect whether this is a git repo and which repo it is
   - confirm whether the target files/repo already exist locally
3. Verify the task target before continuing:
   - repo URL or repo name
   - current local path
   - branch or checkout state if relevant
4. Search for concrete evidence of the requested artifact before claiming progress:
   - skill files
   - README
   - config/manifests
   - remote URL / git metadata
5. If context may be from an earlier session, use session_search with keywords from the task before asking the user to restate everything.
6. Summarize:
   - what is verified
   - what is missing
   - the exact next action once the gap is filled
7. Only then continue the original task.

## Guardrails
- Never trust a stale todo list over live evidence.
- Never send tool calls with missing required parameters.
- Do not claim a repo was cloned, inspected, or summarized unless the filesystem/git state confirms it.
- If the only missing fact is a single identifier (for example repo URL vs “use current workspace”), ask only for that one fact.
- Prefer a short verified recap over speculative continuation.

## Useful recovery checklist
- `pwd`
- identify repo root and remote
- `git status --short --branch`
- locate candidate task files with search_files
- inspect README or manifest files
- load relevant skill once the domain is identified

## Example outcome
"I can continue, but first I verified that the current workspace is X and that the expected target repo/file is not yet confirmed. I need exactly one missing input: repo URL, repo name, or confirmation to use the current workspace."